# Paquete de portadas editoriales

Cuatro portadas independientes, en WebP a 1280 × 800 px (16:10):

- `assets/restauracion-pinturas.webp`: pintura original generada digitalmente, con envejecimiento cromático ilustrativo. **No** representa una restauración real ni la obra Santa Catalina.
- `assets/roc-auc-calibracion.webp`: ilustración conceptual de curvas y clasificación, **no** datos reales ni un gráfico experimental.
- `assets/grafos-arista.webp`: ilustración conceptual de una red y una conexión destacada.
- `assets/series-temporales-transformers.webp`: ilustración vectorial de una serie temporal con predicciones conceptuales; no contiene valores experimentales.
- `assets/series-temporales-transformers.svg`: fuente editable del diseño de series temporales, de creación original.

Las tres primeras portadas proceden de recursos gráficos generados para esta conversación, recortados expresamente como imágenes independientes; no son capturas reales de la web del usuario. Ninguna porta textos incrustados.

`PROMPT_CODEX.md` contiene las instrucciones listas para dar a Codex. `vista_previa.jpg` muestra el conjunto.

Precisión editorial: las ilustraciones no demuestran resultados científicos. No atribuir el retrato de portada al Thyssen ni al Metropolitan Museum. La atribución de imágenes experimentales CC0 dentro del artículo debe permanecer intacta.
